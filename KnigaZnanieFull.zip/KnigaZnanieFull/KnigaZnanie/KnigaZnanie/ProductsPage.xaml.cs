﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KnigaZnanie
{
    /// <summary>
    /// Логика взаимодействия для ProductsPage.xaml
    /// </summary>
    public partial class ProductsPage : Page
    {
        private KnigaZnanieEntities db = new KnigaZnanieEntities();
        public ProductsPage()
        {
            InitializeComponent();
            CategoryBox.Items.Add("Все категории");

            foreach (var category in db.Products
                         .Select(p => p.Category)
                         .Distinct()
                         .ToList())
            {
                if (category != null)
                    CategoryBox.Items.Add(category);
            }

            CategoryBox.SelectedIndex = 0;
            LoadProducts();
        }

        private void LoadProducts()
        {
            var products = db.Products.AsQueryable();

            if (!string.IsNullOrWhiteSpace(SearchBox.Text))
            {
                string search = SearchBox.Text.ToLower();

                products = products.Where(p =>
                    p.ProductName.ToLower().Contains(search) ||
                    p.Manufacturer.ToLower().Contains(search));
            }

            if (CategoryBox.SelectedIndex > 0)
            {
                string category = CategoryBox.SelectedItem.ToString();
                products = products.Where(p => p.Category == category);
            }

            if (DiscountCheck.IsChecked == true)
            {
                products = products.Where(p => p.Discount > 14);
            }

            ProductsGrid.ItemsSource = products.ToList()
                .Select(p => new
                {
                    p.Article,
                    p.ProductName,
                    p.Category,
                    p.Manufacturer,
                    p.Price,
                    EffectiveDiscount = (double)p.Discount,
                    FinalPrice = p.Price * (1 - (decimal)p.Discount / 100),
                    p.Quantity,
                    HasBigDiscount = p.Discount > 14
                }).ToList();
        }
        private void FilterChanged(object sender, RoutedEventArgs e)
        {
            if (IsLoaded && CategoryBox.SelectedItem != null)
                LoadProducts();
        }

        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            SearchBox.Clear();
            CategoryBox.SelectedIndex = 0;
            DiscountCheck.IsChecked = false;
            LoadProducts();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Функция добавления пока не настроена.");
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            if (ProductsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите товар.");
                return;
            }

            MessageBox.Show("Функция изменения пока не настроена.");
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (ProductsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите товар.");
                return;
            }

            MessageBox.Show("Функция удаления пока не настроена.");
        }
    }
}
