﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace KnigaZnanie
{
    public class DiscountConverter : IValueConverter
    {
        public object Convert(object value, Type targetType,
            object parameter, CultureInfo culture)
        {
            if (value == null)
                return Brushes.White;

            double discount = System.Convert.ToDouble(value);


            return discount > 14
                ? Brushes.LightCoral
                : Brushes.White;

            return Brushes.White;
        }

        public object ConvertBack(object value, Type targetType,
            object parameter, CultureInfo culture)
        {
            return Binding.DoNothing;
        }
    }
}