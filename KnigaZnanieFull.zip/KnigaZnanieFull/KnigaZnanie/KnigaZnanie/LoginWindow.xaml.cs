﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace KnigaZnanie
{
    /// <summary>
    /// Логика взаимодействия для LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }
        private void Login_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginBox.Text.Trim().ToLower();
            string password = PasswordBox.Password;
            string role = (RoleBox.SelectedItem as ComboBoxItem)
                ?.Content.ToString();

            bool valid =
                (login == "uchebnikov@mail.com" && password == "Admin01" && role == "Администратор") ||
                (login == "zadachnikova@mail.com" && password == "Admin02" && role == "Администратор") ||
                (login == "atlasov@mail.com" && password == "Manager01" && role == "Менеджер") ||
                (login == "slovareva@mail.com" && password == "Manager02" && role == "Менеджер") ||
                (login == "tetradkin@mail.com" && password == "Guest01" && role == "Авторизованный клиент") ||
                (login == "hrestomatova@mail.com" && password == "Guest02" && role == "Авторизованный клиент") ||
                (login == "reshebnikov@mail.com" && password == "Guest03" && role == "Авторизованный клиент") ||
                (login == "entsiklopedeva@mail.com" && password == "Guest04" && role == "Авторизованный клиент");

            if (valid)
            {
                MainWindow main = new MainWindow();
                main.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show(
                    "Неверный логин, пароль или роль!",
                    "Ошибка авторизации",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
            }
        }

    }
    
}
