﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KnigaZnanie
{
    /// <summary>
    /// Логика взаимодействия для PickupPointsPage.xaml
    /// </summary>
    public partial class PickupPointsPage : Page
    {
        private KnigaZnanieEntities db = new KnigaZnanieEntities();
        public PickupPointsPage()
        {
            InitializeComponent();
            LoadPoints();
        }
        private void LoadPoints()
        {
            var points = db.PickupPoints.AsQueryable();

            if (!string.IsNullOrWhiteSpace(SearchBox.Text))
            {
                string search = SearchBox.Text.ToLower();

                points = points.Where(p =>
                    p.Address.ToLower().Contains(search));
            }

            PickupPointsGrid.ItemsSource = points.ToList();
        }
        private void FilterChanged(object sender, RoutedEventArgs e)
        {
            if (IsLoaded)
                LoadPoints();
        }

        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            SearchBox.Clear();
            LoadPoints();
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            db.Dispose();
            db = new KnigaZnanieEntities();
            LoadPoints();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            ShowAddressDialog(null);
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            PickupPoints point =
                 PickupPointsGrid.SelectedItem as PickupPoints;

            if (point == null)
            {
                MessageBox.Show("Выберите пункт выдачи.");
                return;
            }

            ShowAddressDialog(point);
        }
        private void ShowAddressDialog(PickupPoints point)
        {
            Window dialog = new Window
            {
                Title = point == null
                    ? "Добавление пункта"
                    : "Изменение пункта",
                Width = 400,
                Height = 170,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                ResizeMode = ResizeMode.NoResize
            };

            StackPanel panel = new StackPanel
            {
                Margin = new Thickness(15)
            };

            TextBlock label = new TextBlock
            {
                Text = "Адрес пункта выдачи:"
            };

            TextBox addressBox = new TextBox
            {
                Margin = new Thickness(0, 8, 0, 12),
                Text = point == null ? "" : point.Address
            };

            Button saveButton = new Button
            {
                Content = "Сохранить",
                Width = 110,
                HorizontalAlignment = HorizontalAlignment.Right
            };

            saveButton.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(addressBox.Text))
                {
                    MessageBox.Show("Введите адрес.");
                    return;
                }

                try
                {
                    if (point == null)
                    {
                        PickupPoints newPoint = new PickupPoints
                        {
                            Address = addressBox.Text.Trim()
                        };

                        db.PickupPoints.Add(newPoint);
                    }
                    else
                    {
                        point.Address = addressBox.Text.Trim();
                    }

                    db.SaveChanges();
                    LoadPoints();

                    dialog.DialogResult = true;
                    dialog.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка сохранения: " + ex.Message);
                }
            };

            panel.Children.Add(label);
            panel.Children.Add(addressBox);
            panel.Children.Add(saveButton);

            dialog.Content = panel;
            dialog.ShowDialog();
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            PickupPoints point =
                PickupPointsGrid.SelectedItem as PickupPoints;

            if (point == null)
            {
                MessageBox.Show("Выберите пункт выдачи.");
                return;
            }

            MessageBoxResult result = MessageBox.Show(
                "Удалить выбранный пункт выдачи?",
                "Подтверждение",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result != MessageBoxResult.Yes)
                return;

            try
            {
                db.PickupPoints.Remove(point);
                db.SaveChanges();
                LoadPoints();

                MessageBox.Show("Пункт выдачи удалён.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Не удалось удалить пункт. Возможно, он используется в заказах.\n" +
                    ex.Message);
            }
        }
    }
}
