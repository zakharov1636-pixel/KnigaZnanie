﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KnigaZnanie
{
    /// <summary>
    /// Логика взаимодействия для UsersPage.xaml
    /// </summary>
    public partial class UsersPage : Page
    {
        private KnigaZnanieEntities db = new KnigaZnanieEntities();
        public UsersPage()
        {
            InitializeComponent();
            RoleBox.Items.Add("Все роли");

            foreach (var role in db.Users
                         .Select(u => u.UserRole)
                         .Distinct()
                         .ToList())
            {
                if (role != null)
                    RoleBox.Items.Add(role);
            }

            RoleBox.SelectedIndex = 0;
            LoadUsers();
        }
        private void LoadUsers()
        {
            var users = db.Users.AsQueryable();

            if (!string.IsNullOrWhiteSpace(SearchBox.Text))
            {
                string search = SearchBox.Text.ToLower();

                users = users.Where(u =>
                    (u.FullName != null &&
                     u.FullName.ToLower().Contains(search)) ||
                    (u.Login != null &&
                     u.Login.ToLower().Contains(search)));
            }

            if (RoleBox.SelectedIndex > 0)
            {
                string role = RoleBox.SelectedItem.ToString();
                users = users.Where(u => u.UserRole == role);
            }

            UsersGrid.ItemsSource = users.ToList();
        }
        private void FilterChanged(object sender, RoutedEventArgs e)
        {
            if (IsLoaded && RoleBox.SelectedItem != null)
                LoadUsers();
        }

        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            SearchBox.Clear();
            RoleBox.SelectedIndex = 0;
            LoadUsers();
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            db.Dispose();
            db = new KnigaZnanieEntities();

            RoleBox.Items.Clear();
            RoleBox.Items.Add("Все роли");

            foreach (var role in db.Users
                         .Select(u => u.UserRole)
                         .Distinct()
                         .ToList())
            {
                if (role != null)
                    RoleBox.Items.Add(role);
            }

            RoleBox.SelectedIndex = 0;
            LoadUsers();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            ShowUserDialog(null);
        }
        private void ShowUserDialog(Users user)
        {
            Window dialog = new Window
            {
                Title = user == null
                    ? "Добавление пользователя"
                    : "Изменение пользователя",
                Width = 400,
                Height = 300,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                ResizeMode = ResizeMode.NoResize
            };

            StackPanel panel = new StackPanel
            {
                Margin = new Thickness(15)
            };

            TextBox nameBox = new TextBox
            {
                Margin = new Thickness(0, 5, 0, 10),
                Text = user == null ? "" : user.FullName
            };

            TextBox roleBox = new TextBox
            {
                Margin = new Thickness(0, 5, 0, 10),
                Text = user == null ? "" : user.UserRole
            };

            TextBox loginBox = new TextBox
            {
                Margin = new Thickness(0, 5, 0, 10),
                Text = user == null ? "" : user.Login
            };

            panel.Children.Add(new TextBlock { Text = "ФИО:" });
            panel.Children.Add(nameBox);
            panel.Children.Add(new TextBlock { Text = "Роль:" });
            panel.Children.Add(roleBox);
            panel.Children.Add(new TextBlock { Text = "Логин:" });
            panel.Children.Add(loginBox);

            Button saveButton = new Button
            {
                Content = "Сохранить",
                Margin = new Thickness(0, 10, 0, 0)
            };

            saveButton.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(nameBox.Text) ||
                    string.IsNullOrWhiteSpace(roleBox.Text) ||
                    string.IsNullOrWhiteSpace(loginBox.Text))
                {
                    MessageBox.Show("Заполните все поля.");
                    return;
                }

                try
                {
                    if (user == null)
                    {
                        Users newUser = new Users
                        {
                            FullName = nameBox.Text.Trim(),
                            UserRole = roleBox.Text.Trim(),
                            Login = loginBox.Text.Trim()
                        };

                        db.Users.Add(newUser);
                    }
                    else
                    {
                        user.FullName = nameBox.Text.Trim();
                        user.UserRole = roleBox.Text.Trim();
                        user.Login = loginBox.Text.Trim();
                    }

                    db.SaveChanges();
                    Refresh_Click(null, null);

                    dialog.DialogResult = true;
                    dialog.Close();

                    MessageBox.Show("Данные пользователя сохранены.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка сохранения: " + ex.Message);
                }
            };

            panel.Children.Add(saveButton);
            dialog.Content = panel;
            dialog.ShowDialog();
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            Users user = UsersGrid.SelectedItem as Users;

            if (user == null)
            {
                MessageBox.Show("Выберите пользователя.");
                return;
            }

            ShowUserDialog(user);
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            Users user = UsersGrid.SelectedItem as Users;

            if (user == null)
            {
                MessageBox.Show("Выберите пользователя.");
                return;
            }

            MessageBoxResult result = MessageBox.Show(
                "Удалить выбранного пользователя?",
                "Подтверждение",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result != MessageBoxResult.Yes)
                return;

            try
            {
                db.Users.Remove(user);
                db.SaveChanges();

                Refresh_Click(null, null);
                MessageBox.Show("Пользователь удалён.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Не удалось удалить пользователя. Возможно, он связан с заказами.\n" +
                    ex.Message);
            }
        }
    }
}
