﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KnigaZnanie
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            MainContent.Content = null;
        }

        private void Products_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Navigate(new ProductsPage());
        }

        private void Orders_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Navigate(new OrdersPage());
        }

        private void Users_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Navigate(new UsersPage());
        }

        private void Points_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Navigate(new PickupPointsPage());
        }
    }
}
