﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KnigaZnanie
{
    /// <summary>
    /// Логика взаимодействия для OrdersPage.xaml
    /// </summary>
    public partial class OrdersPage : Page
    {
        private KnigaZnanieEntities db = new KnigaZnanieEntities();

        public OrdersPage()
        {
            InitializeComponent();
            StatusBox.Items.Add("Все статусы");

            foreach (var status in db.Orders
                         .Select(o => o.Status)
                         .Distinct()
                         .ToList())
            {
                if (status != null)
                    StatusBox.Items.Add(status);
            }

            StatusBox.SelectedIndex = 0;
            LoadOrders();
        }

        private void LoadOrders()
        {
            var orders = db.Orders.AsQueryable();

            if (!string.IsNullOrWhiteSpace(SearchBox.Text))
            {
                string search = SearchBox.Text.ToLower();

                orders = orders.Where(o =>
                    o.OrderID.ToString().Contains(search) ||
                    o.Status.ToLower().Contains(search));
            }

            if (StatusBox.SelectedIndex > 0)
            {
                string status = StatusBox.SelectedItem.ToString();
                orders = orders.Where(o => o.Status == status);
            }

            OrdersGrid.ItemsSource = orders.ToList();
        }
        private void FilterChanged(object sender, RoutedEventArgs e)
        {
            if (IsLoaded && StatusBox.SelectedItem != null)
                LoadOrders();
        }

        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            SearchBox.Clear();
            StatusBox.SelectedIndex = 0;
            LoadOrders();
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            db.Dispose();
            db = new KnigaZnanieEntities();
            LoadOrders();
        }

        private void Details_Click(object sender, RoutedEventArgs e)
        {
            if (OrdersGrid.SelectedItem == null)
            {
                MessageBox.Show("Сначала выберите заказ.");
                return;
            }

            dynamic order = OrdersGrid.SelectedItem;
            int orderId = order.OrderID;

            var items = db.OrderItems
                .Where(i => i.OrderID == orderId)
                .ToList();

            if (items.Count == 0)
            {
                MessageBox.Show("Состав заказа не найден.");
                return;
            }

            string result = "Состав заказа №" + orderId + "\n\n";

            foreach (var item in items)
            {
                result += "Артикул: " + item.Article +
                          ", количество: " + item.Quantity + "\n";
            }

            MessageBox.Show(result, "Состав заказа");
        }
    }
}
